#include <stdio.h>

int main()
{

    int a = 40;
    int b = 3;
    int c = a % b;

    printf("40 x 3 = %i\n", a * b);
    printf("40 / 3 = %i\n", a / b);
    printf("40 a 3 = %i\n", c);

    return 0;
}