#include <stdio.h>

int main()
{
    printf("Para criar programas em C, você precisa de um editor de texto e um compilador.\n");

    printf("O compilador GCC (GNU Compiler Collection) é muito utilizado para o desenvolvimento de software.\n");

    printf("Ele inclui front ends para as linguagens C, C++, Objective-C, Fortran, Ada e Go.\n");

    return 0;
}