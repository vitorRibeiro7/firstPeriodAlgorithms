#include <stdio.h>

int main()
{
    printf("Bem vindo a codificação em C/C++!");

    return 0;
}