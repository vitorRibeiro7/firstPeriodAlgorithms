#include <stdio.h>

int main()
{

    int a = 8;
    int b = 5;

    printf("8 + 5 = %i\n", a + b); //PRIMEIRA FORMA DE SE FAZER

    int d = a - b; // FORMA ALTERNATIVA

    printf("8 - 5 = %i\n", d);

    return 0;
}