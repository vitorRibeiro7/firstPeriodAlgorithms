#include <stdio.h>

int main()
{

    int idade = 18;
    float pi = 3.14;
    char tipoSanguineo = 'O';

    printf("Sua idade é %i\n", idade);
    printf("O valor do numeoro pi é %.2f...\n", pi);
    printf("Seu tipo sanguineo é: %c", tipoSanguineo);

    return 0;
}